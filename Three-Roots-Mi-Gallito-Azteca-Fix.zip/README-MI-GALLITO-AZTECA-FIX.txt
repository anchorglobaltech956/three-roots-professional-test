MI GALLITO AZTECA IMAGE FIX

This patch fixes the Mi Gallito Azteca product photo.

Files included:
- index.html
- media-10.webp

What changed:
- media-10.webp was replaced with the correct feed photo for Mi Gallito Azteca.
- index.html already points Mi Gallito Azteca to media-10.webp.

For Hostinger:
1. Open public_html.
2. Upload media-10.webp and overwrite the old file.
3. Upload index.html only if you want to refresh it too.
4. Hard refresh the website with Ctrl+F5.

Fastest option:
If the rest of the site is already correct, you only need to replace media-10.webp.
